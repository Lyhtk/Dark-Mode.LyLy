var btn = document.querySelector("button");
btn.onclick = () =>{
    window.print();
}