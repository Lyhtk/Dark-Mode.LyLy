<div class="footer-top-area" style="height:300px" >
        <div class="zigzag-bottom" ></div>
        <div class="container" >
            <div class="row"  >

                <div class="col-md-3 contact_right" style="float:left">
            <h2> Hỗ trợ</h2>
            <address class="address">
              <p>Trường Đại học Sư Phạm <br>Quận Liên Chiểu,TP Đà Nẵng</p>
              <dl>
                 <dt></dt>
                 <dd>Phone:<span> (+84)-0123456789</span></dd>
                 <dd>FAX: <span>(+84) - (28) - 38398946</span></dd>
                 <dd>E-mail:&nbsp; <a href="https://mail.google.com/mail/u/0/#inbox">trunglythaotrieuthuongluan18cntt3@gmail.com</a></dd>
              </dl>
           </address>
         </div>
                  
                
                <div class="col-md-4 col-sm-6"  >
                    <div class="footer-menu">
                        <h2 class="footer-wid-title">Điều hướng người dùng </h2>
                        <ul>
                            <li><a href="?controller=account">Tài khoản</a></li> 
                            <li><a href="">Danh sách yêu thích</a></li>
                            <li><a href="?controller=contact">Liên hệ nhà cung cấp</a></li>
                            <li><a href="">Trang đầu</a></li>
                        </ul>                        
                    </div>
                </div>
               
                
                
                <div class="col-md-4 col-sm-6">
                    <div class="footer-newsletter" >
                        <h2 class="footer-wid-title">Bản tin</h2>
                        <p>Đăng ký nhận bản tin của chúng tôi và nhận các ưu đãi độc quyền mà bạn sẽ không tìm thấy bất cứ nơi nào khác trực tiếp đến hộp thư đến của bạn!</p>
                        <div class="newsletter-form">
                            <input type="email" placeholder="Nhập email của bạn">
                            <input type="submit" value="Đăng kí">
                        </div>
                    </div>
                </div>
                
           

            </div>
        </div>
    </div>
    <div class="footer-bottom-area" style="height:50px;">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="copyright">
                       <p> @Bookstore-2020 18CNTT3 Ngọc Trung - Kim Ly - Dạ Thảo - Nam Triều - Trọng Thưởng - Hữu Luân <a target="_blank"></a></p>
                    </div>
                </div>
                
               
            </div>
        </div>
    </div>

    <!-- Latest jQuery form server -->
    <script src="https://code.jquery.com/jquery.min.js"></script>
    
    <!-- Bootstrap JS form CDN -->
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    
    <!-- jQuery sticky menu -->
    <script src="public/js/owl.carousel.min.js"></script>
    <script src="public/js/jquery.sticky.js"></script>
    
    <!-- jQuery easing -->
    <script src="public/js/jquery.easing.1.3.min.js"></script>
    
    <!-- Main Script -->
    <script src="public/js/main.js"></script>

    <script src="public/script/initialScript.js"></script>
    
    <!-- Slider -->
    <script type="text/javascript" src="public/js/bxslider.min.js"></script>
    <script type="text/javascript" src="public/js/script.slider.js"></script>
  </body>
</html>