<div class="slider-area">
	<!-- Slider -->
	<div class="block-slider block-slider4">

		<ul class="" id="bxslider-home4">
			<li>
				<img src="../img/bn.jpg" alt="Slide">
				<!-- <div class="caption-group">
							<h3 class="caption title">
								Hành trình <span class="primary">về <strong>Phương Đông</strong></span>
							</h3>
							<h4 class="caption subtitle">- Blair T.Spalding -</h4>
							<a class="caption button-radius" href="#"><span class="icon"></span>Mua ngay</a>
						</div> -->
			</li>
			<li>
				<img src="../img/4.png" alt="Slide">
				<div class="caption-group">
					<h3 class="caption title">
						Nhập mã <u>333</u> <span class="primary">để nhận ưu đãi giảm giá bất ngờ !</span>
					</h3>
					<h4 class="caption subtitle">Thỏa sức đọc sách</h4>
					<a class="caption button-radius" href="#"><span class="icon"></span>Mua ngay</a>
				</div>
			</li>
			<li><img src="../img/h4-slide2.png" alt="Slide">
				<div class="caption-group">
					<h3 class="caption title">
						Lối sống <span class="primary">Tối giản <strong>của người Nhật</strong></span>
					</h3>
					<h4 class="caption subtitle">- Sasaki Fumio -</h4>
					<a class="caption button-radius" href="#"><span class="icon"></span>Mua ngay</a>
				</div>
			</li>
			<li><img src="../img/2.png" alt="Slide">
				<div class="caption-group">
					<h3 class="caption title">
						Nhập mã <u>333</u> <span class="primary">để nhận ưu đãi giảm giá bất ngờ !</span>
					</h3>
					<h4 class="caption subtitle">Thỏa sức đọc sách</h4>
					<a class="caption button-radius" href="#"><span class="icon"></span>Mua ngay</a>
				</div>
			</li>
		</ul>
	</div>
	<!-- ./Slider -->
</div> <!-- End slider area -->