
        function ShowProfile() {
            var PF = document.getElementById('PF');
            var OD = document.getElementById('OD');
            PF.style.display = 'block';
            OD.style.display = 'none';
        }
        function ShowOrder() {
            var PF = document.getElementById('PF');
            var OD = document.getElementById('OD');
            OD.style.display = 'block';
            PF.style.display = 'none';
        }