<!DOCTYPE html>
<html>
<head>
  <title>Quản lí</title>
  <!--SIDE menu-->
  <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <script type="text/javascript" src="jquery-3.3.1.min.js"></script> 
  <script type="text/javascript" src="public/js/side-menu.js"></script>
  <link rel="stylesheet" href="css/styleadmin.css">
</head>